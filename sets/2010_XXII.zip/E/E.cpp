#include <iostream>
#include <cmath>
using namespace std;

int main()
{ int x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,y4,z4;
  int a1,a2,a3,b1,b2,b3,c1,c2,c3;
  
  cin >> x1 >> y1 >> z1 >> x2 >> y2 >> z2 
      >> x3 >> y3 >> z3 >> x4 >> y4 >> z4;
         
  while(cin.good())
  { int a1=x2-x1, a2=y2-y1, a3=z2-z1;
    int b1=x3-x1, b2=y3-y1, b3=z3-z1;
    int c1=x4-x1, c2=y4-y1, c3=z4-z1;
    
    int det =  a1*b2*c3 + a2*b3*c1 + b1*c2*a3
              -c1*b2*a3 - b1*a2*c3 - c2*b3*a1;
              
    int p = abs(det), q=6;
    
    if(p%2==0) { p = p/2; q=q/2; }
    if(p%3==0) { p = p/3; q=q/3; }
    
    cout << p;
    if(q>1) cout << "/" << q;
    cout << endl;
    
    cin >> x1 >> y1 >> z1 >> x2 >> y2 >> z2 
        >> x3 >> y3 >> z3 >> x4 >> y4 >> z4;
  
  }

  return 0;
}
