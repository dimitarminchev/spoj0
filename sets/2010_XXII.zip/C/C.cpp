#include <iostream>
#include <string>
using namespace std;
char str1[20],str2[20],op;
int a,b,c,brt;

int rom210(char str[])
{  
 int a,b=0,n,rez=0;
 char rom[]={'I', 'V','X','L','C','D','M'}; 
 n=strlen(str);
 for (int i=0; i<n;i++)
 {
   switch (str[i]){
     case  'I': a=1; break;      
     case  'V': a=5; break; 
     case  'X': a=10; break; 
     case  'L': a=50; break; 
     case  'C': a=100; break; 
     case  'D': a=500; break; 
     case  'M': a=1000; break; 
     case  'i': a=1; break;      
     case  'v': a=5; break; 
     case  'x': a=10; break; 
     case  'l': a=50; break; 
     case  'c': a=100; break; 
     case  'd': a=500; break; 
     case  'm': a=1000; break; 
     }
   rez+=a;
   if (a>b) rez-=2*b;
   b=a;
   }
 return rez;        
}

void dec2rom(int an)
{  
 int poz,ch,n;
 string rom[]={"I","X","C","M",
               "II", "XX", "CC", "MM",
               "III", "XXX", "CCC", "MMM",
               "IV", "XL","CD"," ",
               "V","L","D"," ",
               "VI","LX","DC"," ", 
               "VII","LXX","DCC"," ",  
               "VIII","LXXX","DCCC"," ", 
               "IX","XC","CM"," " };
 string str[7];
 poz=0; 
 do{
     str[poz]=""; 
     ch=an % 10;
     poz=poz+1;
     if(ch>0)
     { 
       n=(ch-1)*4+poz-1;
       str[poz-1]=rom[n];
     }
     an=an/10;
    }while (an>0);
 for (int i=poz-1; i>=0;i--)if (str[i]!=" ")cout <<str[i];
 cout <<endl;
}

int main()
{
 cin >>brt; 
 for (int i=0;i<brt;i++)
 {   
  cin >>str1;
  cin >>str2;
  cin >>op;
  a=rom210(str1);
  b=rom210(str2);
  switch (op)
  {
     case  '+': c=a+b; break;      
     case  '-': c=a-b; break; 
     case  '*': c=a*b; break; 
     case  '/': c=a/b; break; 
  }    
// cout <<a<<" "<<b<<" "<<c;
  dec2rom(c);
 } 
}

 
