#include<iostream>
#include<queue>


using namespace std;

int fp[1000][100];
int pos[1000][2];

void init_fp(int n,int m)
{
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
		{cin>>fp[i][j];fp[i][j]--;}
}


void init_pos(int n,int m,int ns)
{for(int i=0;i<n;i++) pos[i][0]=0;
queue<int> q;
int j;
q.push(ns);pos[ns][0]=1;
while(!q.empty())
{
	i=q.front();
	q.pop();
	for(j=0;j<m;j++)
		if(!pos[fp[i][j]][0]){q.push(fp[i][j]);pos[fp[i][j]][0]=1;}
}
}



bool r(int i,int j, int k,int m)
{
	bool b=true;
	int l=0;
	while(l<m && b)
	{
		int ax=fp[i][l];
		int bx=fp[j][l];
		b=pos[ax][k]==pos[bx][k];
		l++;
	}
	return b;
}


void eqv(int n,int m,bool b)
{
	int f=3;
	b=0;
	for(int i=0;i<n;i++)
	{
		int s=pos[i][b];
		pos[i][!b]=s;
		if(s)
			for(int j=0;j<n;j++)
			if(pos[j][b]!=s)pos[j][!b]=pos[j][b];
			else {  bool bp=r(i,j,b,m);
					if(!bp)pos[j][!b]=f;
					else pos[j][!b]=pos[j][b];}
		f++;b=!b;
	}
}

void print(int n,int k, bool b)
{
	int t=pos[k][b];
	bool bn=false;
	if(t)
	for(int i=0;i<n;i++)
		if(pos[i][b]==t && i!=k){cout<<i+1<<" ";bn=true;}
	if(!bn)cout<<-1;
}





void main()
{ int n,m,k,ns;
  cin>>n>>m>>k>>ns;
  k--;ns--;
  init_fp(n,m);
  init_pos(n,m,ns);
  int cz,t;
  cin>>cz;
  //markirane na zakl systoiania kato novo mnojestvo
  for(int i=0;i<cz;i++) {cin>>t; if(pos[t-1][0]) pos[t-1][0]=2;}
  bool b=0;
  eqv(n,m,b);
  print(n,k,b);

 	  
}

