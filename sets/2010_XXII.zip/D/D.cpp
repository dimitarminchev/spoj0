#include <stdio.h>
#include <vector>
#include <queue>
using namespace std;
#define MAX_N 10000
long NrEx, i, NrV;
bool SP;

long GCD(long a, long b)
{
  if (!b) return a;
  else return GCD (b, a % b);
}

bool Verif (long NV)
{
     long i, first, next;
     scanf("%d", &first);
     scanf("%d", &next);
     NV-=2;
     next/=GCD(first,next);
     while ((next>1)&&(NV>0))
     {
           scanf("%d", &first);
           next/=GCD(first,next);
           NV--;
     }
     for (int j=1;j<=NV;j++)
           scanf("%d", &first);
     return next==1;
}
           
int main()
{
    scanf("%d", &NrEx); 
    for (int j=0;j<NrEx;j++)
    {
        scanf("%d", &NrV); 
        SP=Verif(NrV);
        if (SP) printf("1\n");
        else printf("0\n");
    }
}
        
