/*  AUTHOR: Lasko Laskov    */
/*  Parallel line segments  */
/*  2010, Ruse              */

#include <cstdlib>
#include <iostream>
#include <cmath>

#define MAX_LINES 10000
#define MAX_BINS 10000
#define PI 3.1415926
#define EMPTY -1

using namespace std;

struct Point
{
    int x;
    int y;
};

struct Segment
{
    Point a;
    Point b;
    int class_key;
    int next;
};

inline bool onCommonLine(const Segment &seg_1, const Segment &seg_2)
{
    int det_1 = 
          seg_1.a.x * seg_1.b.y 
        + seg_1.b.x * seg_2.a.y
        + seg_1.a.y * seg_2.a.x
        - seg_1.b.y * seg_2.a.x
        - seg_1.b.x * seg_1.a.y
        - seg_1.a.x * seg_2.a.y;

    int det_2 = 
          seg_1.a.x * seg_1.b.y 
        + seg_1.b.x * seg_2.b.y
        + seg_1.a.y * seg_2.b.x
        - seg_1.b.y * seg_2.b.x
        - seg_1.b.x * seg_1.a.y
        - seg_1.a.x * seg_2.b.y;

        
    return (det_1 == 0 && det_2 == 0 ? true : false);
}//onCommonLine

void printSegments(Segment seg_arr[], int seg_numb)
{
    for (int indx_seg = 0; indx_seg < seg_numb; indx_seg++)
    {
        cout << "[" << indx_seg << "]" << endl;
        cout << "key " << seg_arr[indx_seg].class_key << endl;
        cout << "next " << seg_arr[indx_seg].next << endl << endl;
    }
}

int main()
{
    Segment seg_arr[MAX_LINES];                     // keeps the line segments
    int seg_numb = 0;                               // number of segments
    while (cin >> seg_numb)
    {
        int cl_vote[MAX_BINS] = {0};                // class vote array
        int cl_last[MAX_BINS];                      // keep the last voted seg.
        
        for (int cl_indx = 0; cl_indx < MAX_BINS; cl_indx++)
        {
            cl_last[cl_indx] = EMPTY;
        }
        
// read the input data ---------------------------------------------------------
        for (int indx_seg = 0; indx_seg < seg_numb; indx_seg++)
        {
            cin >> seg_arr[indx_seg].a.x;
            cin >> seg_arr[indx_seg].a.y;
            cin >> seg_arr[indx_seg].b.x;
            cin >> seg_arr[indx_seg].b.y;
            seg_arr[indx_seg].class_key = EMPTY;    // init
            seg_arr[indx_seg].next = EMPTY;         // init
        }
        
// voting scheme to find the parallel segments ---------------------------------
        for (int indx_seg = 0; indx_seg < seg_numb; indx_seg++)
        {
            int nom = seg_arr[indx_seg].a.y - seg_arr[indx_seg].b.y;
            int den = seg_arr[indx_seg].a.x - seg_arr[indx_seg].b.x;
            if (nom == 0 && den != 0)
            {
                // horizontal line segment
                cl_vote[0]++;
                seg_arr[indx_seg].next = cl_last[0];
                seg_arr[indx_seg].class_key = 0;
                cl_last[0] = indx_seg;
            }
            else if (nom != 0 && den == 0)
            {
                // vertical line segment
                cl_vote[MAX_BINS - 1]++;
                seg_arr[indx_seg].next = cl_last[MAX_BINS - 1];
                seg_arr[indx_seg].class_key = MAX_BINS - 1;
                cl_last[MAX_BINS - 1] = indx_seg;
            }
            else
            {
                // assume that nom == 0 && den == 0 is not possible in the input
                // not a special case
                double at = atan2(1.0 * nom, 1.0 * den);
                if (at < 0)
                {
                    at += PI;
                }
                int class_key = ((int)(at * MAX_LINES)) % MAX_BINS;
                cl_vote[class_key]++;
                seg_arr[indx_seg].next = cl_last[class_key];
                seg_arr[indx_seg].class_key = class_key;
                cl_last[class_key] = indx_seg;
            }
        }

// find the cuncurrent lines ---------------------------------------------------
        for (int indx_cl = 0; indx_cl < MAX_BINS; indx_cl++)
        {
            if (cl_vote[indx_cl] > 1)
            {
                int ptr_first = cl_last[indx_cl];
                while (ptr_first != EMPTY)
                {
                    int ptr_curr = seg_arr[ptr_first].next;
                    int ptr_prev = ptr_first;
                    while (ptr_curr != EMPTY)
                    {
                        if (onCommonLine(seg_arr[ptr_first], seg_arr[ptr_curr]))
                        {
                            // both line segments lie on a common line
                            cl_vote[indx_cl]--;
                            
                            // remove the current from the list
                            seg_arr[ptr_prev].next = seg_arr[ptr_curr].next;
                            ptr_curr = seg_arr[ptr_curr].next;
                        }
                        else
                        {
                            ptr_prev = ptr_curr;
                            ptr_curr = seg_arr[ptr_curr].next;   
                        }
                    }
                    ptr_first = seg_arr[ptr_first].next;
                }   
            }
        } 
        
// find the number of classes --------------------------------------------------
        int class_numb = 0;
        for (int indx_cl = 0; indx_cl < MAX_BINS; indx_cl++)
        {
            if (cl_vote[indx_cl] > 1)
            {
                class_numb++;    
            }
        }
        cout << class_numb << endl;
        
        //printSegments(seg_arr, seg_numb);
    }
        
    return 0;
}
