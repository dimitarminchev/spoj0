#include<iostream>
using namespace std;
long long nok(long long a,long long b)
{
	long long x,y;
	x=a; y=b;
	while(a&&b)
		if(a>b) a%=b;
		else b%=a;
		if(a) return x*y/a;
		else return x*y/b;
}
long long t[10001];
int v[10001],b[10001],n;
void read()
{
	int i;
	cin>>n;
	for(i=1;i<=n;i++)
		cin>>v[i];
}
void solve()
{
	int i;
	long long x,nok1,nok2,nok3,nok4;
	t[1]=v[1]; b[1]=1;
	nok1=nok(v[1],v[2]);
	if(nok1>v[1]+v[2])
	{t[2]=nok1; b[2]=2;}
	else
	{
		t[2]=v[1]+v[2];
		b[2]=1;
	}
	nok2=nok(v[2],v[3]);
	nok3=nok(nok1,v[3]);
	t[3]=nok3;b[3]=3;
	if(v[1]+nok2>t[3])
	{
		t[3]=v[1]+nok2;
		b[3]=2;
	}
	if(t[2]+v[3]>t[3])
	{
		t[3]=t[2]+v[3];
		b[3]=1;
	}
	x=nok2;
	nok2=nok(v[3],v[4]);
	nok3=nok(v[2],nok2);
	nok4=nok(nok1,nok2);
	nok1=nok2;
	t[4]=nok4;b[4]=4;
	if(t[3]+v[4]>t[4])
	{
		t[4]=t[3]+v[4];
		b[4]=1;
	}
	if(t[2]+nok2>t[4])
	{
		t[4]=t[2]+nok2;
		b[4]=2;
	}
	if(t[1]+nok3>t[4])
	{
		t[4]=t[1]+nok3;
		b[4]=3;
	}
	for(i=5;i<=n;i++)
	{
		x=nok2;
		nok2=nok(v[i-1],v[i]);
		nok3=nok(v[i-2],nok2);
		nok4=nok(nok1,nok2);
		nok1=x;
		t[i]=t[i-4]+nok4;
		b[i]=4;
		if(t[i-1]+v[i]>t[i])
		{
			t[i]=t[i-1]+v[i];
			b[i]=1;
		}
		if(t[i-2]+nok2>t[i])
		{
			t[i]=t[i-2]+nok2;
			b[i]=2;
		}
		if(t[i-3]+nok3>t[i])
		{
			t[i]=t[i-3]+nok3;
			b[i]=3;
		}
	}
}
void print(int l)
{
	int i;
	if(l>0)
	{
		print(l-b[l]);
		cout<<l-b[l]+1;
		for(i=l-b[l]+2;i<=l;i++)
			cout<<'+'<<i;
		cout<<endl;
	}
}
int main()
{
	int i,k;
	cin>>k;
	while(k--)
	{
		memset(t,0,sizeof(t));
		memset(v,0,sizeof(v));
		memset(b,0,sizeof(b));
		n=0;
		read();
		solve();
		print(n);
	/*for(i=1;i<=n;i++)
		cout<<t[i]<<' '<<b[i]<<endl;*/
	cout<<t[n]<<endl;
	}
	return 0;
}