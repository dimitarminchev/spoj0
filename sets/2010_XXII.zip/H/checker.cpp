#include<iostream>
#include<fstream>
#include<string>
using namespace std;
long long gcd (long long p1, long long p2)
{
   	
	while (p1 > 0 && p2 > 0)
	{
		if (p1 > p2) p1 = p1%p2;
		else
			p2 = p2%p1;
	}
	return max (p1, p2);
}
int n; 
long long a [100100];
int main(int argn, char** argv)
{
    int i,k;
    long long mn, sum,num,sz,d[4],pos=0,nok,otg,cn=0;
    string s,s1,s2;
    char ch;
    
    ifstream in(argv[1]);
    ifstream ans(argv[2]);
    ifstream ansj(argv[3]);
    ofstream out(argv[4]);
    in>>k;
    while(k--)
    {
        in>>n;
        for(i=1;i<=n;i++) in>>a[i];
        ansj>>mn;
        sum=0;
        cn=0;
        do
        {
            num=0;pos=0;
            ans>>s;
        //    cout << s << endl;
            sz=s.size();;
            for(i=0;i<sz;i++)
            {
             if(s[i]>='0'&&s[i]<='9')
             {
                 num*=10;
                 num+=s[i]-'0';
             }
             else 
             {
                 if(num>n)
                 {
                    cout<<"Wrong Answer"<<endl;
                    return 0;
                }
                 d[pos++]=a[num];
                 num=0;
             }
            }
            d[pos++]=a[num];
            nok=d[0];
            for(i=1;i<pos;i++) nok=(nok*d[i])/gcd(nok,d[i]);
            sum+=nok;
            cn+=pos;
       //     cin.get(ch);
        }
        while(cn<n);
        ans>>otg;
        if(sum!=otg||sum!=mn||mn!=otg||cn>n)
        {
            s1 = "<?xml version=\"1.0\"?>";
            out<<s1<<endl;
            s2 = "<result outcome=\"Wrong Answer\" security=resfile.xml> string2 </result>";
            out<<s2<<endl;
           // cout<<"Wrong Answer"<<endl;
            return 0;
        }
        sum=0;
        memset(a,0,sizeof(a));
    }
    s1 = "<?xml version=\"1.0\"?>";
    out<<s1<<endl;
    s2 = "<result outcome=\"Accepted\" security=resfile.xml> string2 </result>";
    out<<s2<<endl;
    //cout<<"Accepted"<<endl;
    return 1;
}
