#include <iostream>
#include <cmath>
using namespace std;

int main()
{ int a,b,c,k,n;
  double dist;
  
  cin >> a >> b >> c >> k >> n;
  while(cin.good())
  { int D=(b-k)*(b-k) - 4*a*(c-n);
  
    if(D>=0) dist=0;
    else dist = abs(c-n-(b-k)*(b-k)/(4*a)) / sqrt(1+k*k);
    cout << floor(dist) << endl;
    
    cin >> a >> b >> c >> k >> n;
  }

  return 0;
}
