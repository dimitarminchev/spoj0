#include <iostream>
using namespace std;

typedef long long int INT;

void e_euclid(INT a, INT b, INT &x, INT &y, INT &d)

// calculates a * x + b * y = gcd(a, b) = d

{
  INT q, r, x1, x2, y1, y2;
  if (b==0) {d = a; x = 1; y = 0; return;}
  x2 = 1, x1 = 0, y2 = 0, y1 = 1;

  while (b > 0)
  {
    q = a / b; r = a - q * b;
    x = x2 - q * x1; y = y2 - q * y1;
    a = b; b = r;
    x2 = x1; x1 = x; y2 = y1; y1 = y;
  }
  d = a; x = x2; y = y2;
}

INT chinese(INT n, INT p[], INT r[])
{
  INT z=0;
  INT pp=1;
  for(INT i=1;i<=n;i++) pp *= p[i];

  for(INT i=1;i<=n;i++)
  {
    INT x, y, d;
    e_euclid(p[i], pp/p[i], x, y, d);
    INT s=y;
    INT e=y*(pp/p[i]);
    while(e<0) e += pp;
    z = (z + r[i]*e)%pp;
  }

  return z;
}


INT p[99], r[99];
INT n;

int main()
{
  int NC;
  cin >> NC;
  for(int tc=1;tc<=NC;tc++)
  {
  cin >> n;
  for(int i=1;i<=n;i++) cin >> p[i];
  for(int i=1;i<=n;i++) cin >> r[i];

  INT res=chinese(n,p,r);
  cout << res << endl;
  }
  return 0;
}
