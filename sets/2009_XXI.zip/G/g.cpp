#include <iostream>
#include <cstdio>
#include <string.h>

using namespace std;

int pre_kmp [ 262144 ], sz;
char word [ 262144 ];

void read ()
{
	gets ( word );
	sz = strlen ( word );
}

int solve ()
{
	int r_pos = 2 , l_pos = 0;
	while ( r_pos <= sz )
	{
		if ( word [ l_pos ] == word [ r_pos - 1 ] )
		{
			pre_kmp [ r_pos ] = l_pos + 1;
			l_pos++;
			r_pos++;
		}
		else
		{
			if ( l_pos != 0 ) l_pos = pre_kmp [ l_pos ];
			else
			{
				pre_kmp [ r_pos ] = 0;
				r_pos ++;
			}
		}
	}
	return ( sz - pre_kmp [ sz ] );
}

int main()
{
    int k, i;
    char c;
    cin >> k;
    cin.get ( c );
    for ( i = 0; i < k; i++)
    {
        read ();
        cout << solve () << endl;
        memset ( pre_kmp, 0, sizeof ( pre_kmp ) );

    }
	return 0;
}
