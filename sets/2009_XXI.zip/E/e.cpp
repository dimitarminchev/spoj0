#include <stdio.h>
#include <string.h>

int main()
{
    int i,j,k; char s[1000000],t[1000000];
    int al[27],razl,min,nach,kr,len;
    
    while(scanf("%s",s) != -1)
    {
      len=strlen(s);strcpy(t,s);
      for(i=0;i<len;i++)
      {
         if(s[i]>='A'&&s[i]<='Z') s[i]+='a'-'A';
         if(s[i]<'a'||s[i]>'z') s[i]='0';                  
      }
      for(i=0;i<26;i++) al[i]=0; razl = 0;
      j=0;
      while(j<len&&razl<26)
      {
         if(s[j]!='0')
         {
             if(al[s[j]-'a']==0) razl++;
             al[s[j]-'a']++;                        
         }
         j++;              
      }
      if(razl<26) printf("0\n"); 
      else 
      {
           
         min=j;nach=0;kr=j-1;i=nach;j=kr;
         while(j<len)
         {
            al[s[i]-'a']--;if(al[s[i]-'a']==0) razl--;i++;
            if(razl==26&&j-i+1<min) {min=j-i+1;nach=i;}
            else
            {
                while(j<len&&razl<26)
                {
                   if(s[j]!='0')
                   {
                      if(al[s[j]-'a']==0) razl++;
                      al[s[j]-'a']++;                        
                    }
                    j++;
                } 
                if(razl==26&&j-i<min) {min=j-i;nach=i;kr=j-1;}
            }   
         }
      
         for(i=nach;i<=kr;i++) printf("%c",t[i]);
         printf("\n");
      }   
  } 
}
