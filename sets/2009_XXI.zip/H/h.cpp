#include <iostream>

using namespace std;

typedef unsigned long long ull;
typedef unsigned short ushort;
typedef unsigned int uint;

uint N, K, t, i;


ull compute ( uint n, uint k )	//sloves the problem for fixed n and k
{
	ull s= (ull) (n+2)*(n+1)*n/6; //sum of all elements in U
	ull k2= k*k;
	ull k3= k2*k;
	ull res= 0;
	for ( uint d= k-1; d<= n-k; d++ )	//d is a number of the serial diagonal,
	{									//parallel to the major diagonal
		ull sq_sum= k3+(d-k+1)*k2;	//sum of all elements in the square kxk matrix
		res += (n-k-d+1)*(s - sq_sum);
	}
	return res;
}

// a bit faster than compute, but not so clear
//ull compute2 ( uint n, uint k )	
//{
//	ull s= (ull) (n+2)*(n+1)*n/6;
//	uint p= n-2*k+2;
//	uint k2= k*k;
//	uint k3= k*k2;
//	ull res= 0;
//	for ( uint r=p; r>0; r-- )
//		res += r*(s-k3-(p-r)*k2);
//	return res;
//}


int main( )
{
	cin >> t;
	for ( i=0; i<t; i++ )
	{
		cin >> N;
		ull result= 0;
		for ( K=1; K<= (uint) (N+1)/2; K++)
			result += compute ( N, K );
		cout << result << endl;;
	}
	
    return 0;
}
