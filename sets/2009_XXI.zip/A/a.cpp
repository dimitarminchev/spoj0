#include <stdio.h>
int max(int a,int b){return a>=b?a:b;}
int min(int a,int b){return a<=b?a:b;}
int main()
{
    int x1,y1,x2,y2,x3,y3,x4,y4,s,inter;
    while(1)
    {
       if(scanf("%d",&x1)== -1) break;
       scanf("%d %d %d %d %d %d %d",&y1,&x2,&y2,&x3,&y3,&x4,&y4);
       s=(x2-x1)*(y1-y2)+(x4-x3)*(y3-y4);
       if(x3>=x2||x1>=x4||y2>=y3||y4>=y1) inter=0;
       else inter=(min(x2,x4)-max(x1,x3))*(min(y1,y3)-max(y2,y4));
       printf("%d %d %d\n",s,s-inter,inter);         
    }
    return 0;   
}
