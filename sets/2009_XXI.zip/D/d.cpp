#include <stdio.h>

int main()
{
    double A,k,p,r,q; int i,t,T;
    scanf("%d",&T);
    for(t=1;t<=T;t++)
    {
       scanf("%lf %lf %lf",&A,&q,&p);
       i=1;r=A-(p/100.)*A;k=q;
       while (r<50000000000.)
       { r=r+k*A-(p/100)*r;k=k*q;i++;}
       printf("%d\n",i);
   }     
}
