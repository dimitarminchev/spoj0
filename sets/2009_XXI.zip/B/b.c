#include <stdio.h>
#include <memory.h>

#define MAX_SIZE 5001
const int MAX_INT = (int)((unsigned)(-1) >> 1);
int M, N;
int max, min,
    maxF, maxL;

int left[MAX_SIZE];
int front[MAX_SIZE];

int read_data()
{
    int i, h;

    if (scanf("%d %d", &N, &M) != 2)
        return 0;

    memset(left, 0, sizeof(int)*MAX_SIZE);
    memset(front, 0,sizeof(int)*MAX_SIZE);
    maxF = maxL = 0;

    for (i = 0; i < N; ++i)
    {
        scanf("%d" , &h);
        ++front[h];
        if (maxF < h)
            maxF = h;
    }

    for (i = 0; i < M; ++i)
    {
        scanf("%d" , &h);
        ++left[h];
        if (maxL < h)
            maxL = h;
    }
    return 1;
}

void print()
{
    if (max == -1 || min == -1)
        printf("No Solution.\n");
    else
        printf("%d %d\n", min, max);
}

void solve()
{
    int i;
    int usedL = 0, usedF = 0;
    int cur;
    min = max = 0;

    if (maxF != maxL)
    {
            min = -1;
            return;
    }
    
    // Calc max;
    for (i = 0; i <= maxF; ++i)
    {
        if (left[i])
        {
            if (i && ((MAX_INT/(i*left[i])) < N-usedF))
            {
                min = -1;
                puts("OVERFLOW");
                return;
            }

            cur = (N-usedF)*(i*left[i]);
            usedL += left[i];
            max += cur;

            if (max > 2000000000)
            {
                min = -1;
                puts("OVERFLOW");
                return;
            }
        }
        if (front[i])
        {
            if (i && (MAX_INT/(i*front[i])) < M-usedL)
            {
                min = -1; 
                puts("OVERFLOW");
                return;
            }

            cur = (M-usedL)*(i*front[i]);
            usedF += front[i];
            max += cur;

            if (max > 2000000000)
            {
                min = -1; 
                puts("OVERFLOW");
                return;
            }
        }
    }

    // calc min
    for (i = 0; i <= maxF; ++i)
    {
        if (front[i] > left[i])
            min += front[i] * i;
        else
            min += left[i] * i;
    }
}

void main()
{
    while (read_data())
    {
        solve();
        print();
    }
}