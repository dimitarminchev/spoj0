#include <iostream>
#include <cstdio>

using namespace std;

int diff [ 1024 ], n, ans;

void read ()
{
    int i, x, y;
    scanf ( "%d" , &n );

    for( i = 0; i < n; i++ )
    {
        scanf ( "%d%d", &x, &y );
        diff [ i ] = ( abs ( x - y ) - 1 ) ;
        ans ^= ( abs ( x - y ) - 1 );
    }
}

void solve ()
{
    int i;
    if ( ans == 0 ) printf ( "BLACK\n" );
    else
    {
        for ( i = 0; i < n; i++ )
        if (( diff [ i ] ^ ans ) < diff [ i ] )
        {
            printf ( "WHITE %d\n", ( i + 1 ) );
            break;
        }
    }
}

int main ()
{
    int t, j;
    scanf ( "%d", &t );
    for ( j = 0; j < t; j++ )
    {
        read ();
        solve ();
        memset ( diff, 0, sizeof ( diff ) );
        ans = 0;
    }
    return 0;
}
