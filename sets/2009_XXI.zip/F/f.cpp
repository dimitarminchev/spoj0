#include <stdio.h>
#define MAXN 2000
#define MAXS 2*MAXN
int gr[MAXN][MAXN],w[MAXN][MAXN], loop[2*MAXN],used[MAXN],tree[MAXN][2],pt;
int N,M;
typedef struct
{  int e[MAXS+1],top; } int_Stack;
void empty_stack(int_Stack* s)
{  s->top=-1; }
int is_empty_stack(int_Stack* s)
{  if(s->top<0) return 1;
   else return 0;
}
void add_stack(int_Stack* s,int a)
{  s->e[++s->top]=a;}
int look_stack(int_Stack* s)
{  return s->e[s->top];}
void delete_stack(int_Stack* s)
{  s->top--;}
int get_stack(int_Stack* s)
{  return s->e[s->top--];}
int stack_count(int_Stack* s)
{ return s->top+1; }

int next_edge(int v)
{  
   while(gr[v][0]<=N&&gr[v][gr[v][0]]==0)
        gr[v][0]++;
   if(gr[v][0]<=N)
   {  gr[v][gr[v][0]]--; 
      gr[gr[v][0]][v]--;
      return gr[v][0]; 
   }
   else return 0;
}
int BFS(int start,int* last)
{
   int u[MAXN],q[MAXN],b,e,i,max,R;
   for (i=1;i<=N;i++) u[i]= -1;
   b=e=0;q[0]=start;u[start]=0;max=0;R=start;
   while(b<=e)
   {
      int x=q[b++];
      for(i=1;i<=gr[x][0];i++)
      { int y=gr[x][i];
        if(u[y]== -1)
        { u[y]=u[x]+w[x][y];q[++e]=y;
          if(max<u[y]){max=u[y];R=y;}
        }
      }          
   }
   *last=max;
//   for(i=1;i<=N;i++) printf("%d: %d\n",i,u[i]); 
   return R;          
}

int main()
{
   int t,T,B,i,j,x,x1,y,y1;
   scanf("%d",&T);
   for(t=1;t<=T;t++)
   {
      scanf("%d %d",&N,&M);
      for(i=1;i<=N;i++) 
      { gr[i][0]=1;gr[i][N+1]=0;used[i]= -1;
        for(j=1;j<=N;j++) gr[i][j]=w[i][j]=0;
      }
      for(i=1;i<=M;i++)
      {
         scanf("%d %d",&x,&y);
         gr[x][y]=gr[y][x]=1;
         gr[x][N+1]++;gr[y][N+1]++;
      } 
//for(i=1;i<=N;i++)
//{   for(j=1;j<=N;j++) printf("%d ",gr[i][j]);printf("\n");}                      
      for(i=1;i<=N;i++)
         if(gr[i][N+1]>2) break;
      if(i>N) {printf("%d\n",N-1); continue;}
      else B=i;   
//Euler
      int v; int_Stack S;
      empty_stack(&S);add_stack(&S,B);i=0;
      while(!is_empty_stack(&S))
      {  v=look_stack(&S); //printf("look %d\n",v);
          if((v=next_edge(v))!=0) add_stack(&S,v);
          else {loop[i++]=get_stack(&S);/*printf("get %d\n",loop[i-1]);*/} 
      }
      loop[i]=0;int L=i;
      for(i=1;i<=N;i++) gr[i][0]=0;
      x=loop[0];y=0;
      for(j=1;j<L;j++)
      {
         if(gr[loop[j]][N+1]>2) 
         {   if(loop[j]!=x)
             {  //printf("%d %d %d\n",x,loop[j],j-y);
                gr[x][++gr[x][0]]=loop[j];gr[loop[j]][++gr[loop[j]][0]]=x;
                if(w[x][loop[j]]<j-y) w[x][loop[j]]=w[loop[j]][x]=j-y;
             }   
             else 
             {
                //printf("%d %d %d\n",x,loop[j-1],j-y-1);
                gr[x][++gr[x][0]]=loop[j-1];gr[loop[j-1]][++gr[loop[j-1]][0]]=x;
                w[x][loop[j-1]]=w[loop[j-1]][x]=j-y-1;
             }     
             x=loop[j];y=j;
         }
      }
//for(i=1;i<=N;i++)
//{if (gr[i][0]!=0) printf("%d: ",i);for(j=1;j<=gr[i][0];j++) printf("%2d ",gr[i][j]);printf("\n");}           
       
      int mm;
      B=BFS(B,&mm);
      BFS(B,&mm);
      printf("%d\n",mm);
   }
   
   
   return 0;
}
