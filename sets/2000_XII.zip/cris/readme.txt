
uslovieto naktratko: exact matching with set of patterns (N na broi patterns)
        neka m = dyljina na teksta, n = sumata ot dyljnite na N-te pattern-a;
        k = sumata ot occurrences na vseki ot N-te pattern-a
algorythm:
        - the naive algorythm ima O(m*N*n)
        - N pyti KMP ili BM shte imame O(m*N)
        - hubaviq algorythm e O(n+m+k)

v arhiva ima:
.\readMe.txt - tozi file
.\count the words.rtf - ulovieto na zadachata, moje bi ima greshki (ot ezikova gledna tochka),
        nqma da e losho da se pogledne (i koregira tuk tam ako se nalaga)
.\count.pas - reshenieto na zadachata koeto ima slojnost okolo O(n+m+k)
.\tst?.inp i tst?.dat - vhodnite testove (? := 1,2,3,4,5)
.\tst?.sol - otgovorite na syotvetnite testove(? := a,b,c,d,e)
.\run.bat - puska vischk testove, kato sled vsqko izpylnenie sravnqva .out s nujnie .sol i
        pravi "pause"
.\runhlp.bat - puska opredelen test, za parametyr ima nomera na test

.\tools\generate.pas - generator na 5te testa, 1q vinagi e primerniq; syvsem lesno sme smenqt
         harakteriskite na testovete, kato se barne source-a v "begin-end." bloka
.\tools\slow.pas - reshenie na zadachata izpolzvashto mnogo pamet (< 2MB) i mnogo bavno,
        no ochevidno vqrno, izpolzvane za generirane na .sol files
.\tools\ans.bat i anshlp.bat - podobni na rub*.bat, no puskat slow.exe i ne sravnqva, a kopira
        .out -> .sol

na Pentium 120 count.pas vyrvi za
test 1 za <1 sec
test 2 za <3 sec
test 3 za <3 sec
test 4 za <10 sec
test 5 za <10 sec
