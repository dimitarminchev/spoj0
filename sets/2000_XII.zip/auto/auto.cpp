#include "stdio.h"
#define MAXM 1000

	int N,M;int minx,miny,minp;
	int delta[MAXM+1][10], lambda[MAXM+1][10];
	int part[MAXM+1];

onel(int);
void main()
{
	int i,j,k,l,cur,curv,flag;
	FILE *inf,*outf;

	inf=fopen("auto.in","r");
	outf=fopen("auto.out","w");
	fscanf(inf,"%d %d",&N,&M);
	for(i=0;i<M;i++)
	{
		for(j=0;j<=N;j++)
		   fscanf(inf,"%d",delta[i]+j);
		for(j=0;j<=N;j++)
		   fscanf(inf,"%d",lambda[i]+j);
		part[i]= -1;
	}
	part[M]= -1;
	//first split by outputs
	cur=curv=0;part[0]=0;
	while(1)
	{
		for(i=cur+1;i<M;i++)
		{
			flag=1;
			for(j=0;j<=N;j++)
				if(lambda[i][j]!=lambda[cur][j]){flag=0;break;}
			if(flag==1) part[i]=part[cur];
		}
		while (part[++cur]!= -1);
		if(cur==M) break;
		part[cur]= ++curv;
		if(cur==M-1) break;
	}
	if(curv==M-1) fprintf(outf,"%d\n",curv+1); //given is minimal
	else
	{
	   int newv;
           while(curv!=(newv=onel(curv))) curv=newv;
	   fprintf(outf,"%d\n",curv);
	}
}

onel(int cur)
{
	int test[MAXM+1][11];int newpart[MAXM+1];
	for(int i=0;i<M;i++) newpart[i]= -1;
	int newv=0, flag;
	for(i=0;i<=cur;i++) /* for each part i of the old partition */
	{
	  int k=0;
	  for(int j=0;j<M;j++)
	     if(part[j]==i) /* for each state in the part i */
	     {
		for(int l=0;l<=N;l++)
		     test[k][l]=part[delta[j][l]];
		test[k][N+1]=j;
		if(k>0)
		{   for(int k1=0;k1<k;k1++)
		    { flag=0;
		      for(l=0;l<=N;l++)
			 if(test[k][l]!=test[k1][l]) {flag=1;break;}
		      if(flag==0) {newpart[j]=newpart[test[k1][N+1]];break;}
		    }
		    if(flag!=0) {newpart[j]=newv++;k++;}
		}
	       else {newpart[j]=newv++;k++;}
	     }

	}
       for(i=0;i<M;i++) part[i]=newpart[i];
       return(newv);
}