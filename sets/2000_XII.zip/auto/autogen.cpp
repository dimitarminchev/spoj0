#define N 5
#define M 500
#include <stdio.h>
#include <stdlib.h>
void main()
{
 FILE *out; int j,r,s;
 out=fopen("auto.in4","w");
 randomize();
 fprintf(out,"%d %d\n",N,M);
 for(int i=1;i<=M-1;i++)
 {
   for(j=0;j<=N;j++)
   {   r=random(M);
       fprintf(out,"%d ",r);
   }
    fprintf(out,"1 1 0 2 0 4\n");
 }

}