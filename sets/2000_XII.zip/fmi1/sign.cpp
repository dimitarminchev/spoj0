#include <assert.h>
#include <stdio.h>

#define DEBUG		0
#define MAX_D		130

int n, d;
int l[MAX_D], r[MAX_D];
int sum;
unsigned long count;
int gen[MAX_D], counts[MAX_D];

unsigned long var_count(int i) {
  int s[MAX_D], sum_n = 0;
  int j, k, u;

  for (j = 0; j < i; j++) {
    for (k = j-1; k >= 0 && s[k] > counts[j]; k--)
      s[k+1] = s[k];
    s[k+1] = counts[j];
    sum_n += counts[j];
  }

  long double product = 1.0;
  j = 1;
  for (k = 0; k < i; k++)
    for (u = 1; u <= s[k]; u++) {
      product *= j++;
      product /= u;
    }
#if DEBUG
  printf("%ld\n", (long)product);
#endif

  return product;
}

void go (int i, int j) {
  int k, u;

  if (sum == n) {
#if DEBUG
    for (j = 0; j < i; j++)
      for (k = 0; k < counts[j]; k++)
	printf("%4d", l[gen[j]]);
    printf("\n");
#endif
    count += var_count(i);
    return;
  }

  for (k = j; k < d; k++)
    for (u = 1; sum + u*l[k] <= n; u++) {
      gen[i] = k;
      counts[i] = u;
      sum += u*l[k];
      go(i+1,k+1);
      sum -= u*l[k];
    }
}

int main (void) {
  int i, j;
  FILE *f;

  f = fopen("sign.in", "rt");
  assert(f);
  fscanf(f, "%d%d", &n, &d);
  for (i = 0; i < d; i++)
    fscanf(f, "%d", &l[i]);
  fclose(f);

  for (i = 0; i < d; i++) {
    int temp = l[i];
    for (j = i-1; j >= 0 && l[j] > temp; j--)
      l[j+1] = l[j];
    l[j+1] = temp;
  }

#if DEBUG
  printf("\n");
#endif
  count = 0;
  sum = 0;
  go(0, 0);

  f = fopen("sign.out", "wt");
  assert(f);
  fprintf(f, "%lu\n", count);
  fclose(f);

  return 0;
}

