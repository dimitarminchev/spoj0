#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LETTERS		('z'-'a'+1)
#define MAX_WORD_SIZE	21
#define MAX_WORDS	200

struct node {
  struct node *link[LETTERS];
  long count;
  int is_counted;
};

struct node *root;

struct list {
  struct node *node;
  struct list *next;
};

struct list *head;

struct word {
  char s[MAX_WORD_SIZE];
  struct node *node;
};

int n;
struct word words[MAX_WORDS];

struct node * new_node (void) {
  struct node *p = (struct node *)calloc(1, sizeof *p);
  if (!p) {
    perror("new_node");
    exit(1);
  }
  return p;
}

int main (void) {
  FILE *f;
  char w[MAX_WORD_SIZE];
  struct node *p;
  int c;
  int i;

  root = new_node();

  f = fopen("count.in", "rt");
  assert(f);
  while (fscanf(f, "%s", w) == 1) {
    char *pch;
    for (p = root, pch = w; *pch; pch++) {
      i = *pch-'a';
      assert(0 <= i && i < LETTERS);
      if (!p->link[i])
	p->link[i] = new_node();
      p = p->link[i];
    }
    p->is_counted = 1;
    strcpy(words[n].s, w);
    words[n].node = p;
    n++;
  }
  fclose(f);

  f = fopen("count.dat", "rt");
  assert(f);
  head = NULL;
  while ((c = getc(f)) != EOF)
    if (c != '\n') {
      struct list *l, **lprev;
      int i = c-'a';
      assert(0 <= i && i < LETTERS);

      for (lprev=&head, l=head; l; )
	if (l->node->link[i]) {
	  l->node = l->node->link[i];
	  if (l->node->is_counted)
	    l->node->count++;
	  lprev = &l->next;
	  l = l->next;
	}
	else {
	  struct list *oldl = l;
	  l = *lprev = l->next;
	  free(oldl);
	}
      *lprev = NULL;

      if (root->link[i]) {
	struct list *l = (struct list *)malloc(sizeof *p);
	if (!l) {
	  perror("new list node");
	  exit(1);
	}
	l->node = root->link[i];
	l->next = head;
	head = l;

	if (l->node->is_counted)
	  l->node->count++;
      }
    }
  fclose(f);

  f = fopen("count.out", "wt");
  assert(f);
  for (i = 0; i < n; i++)
    fprintf(f, "The word %s occurs %ld time(s).\n",
      words[i].s, words[i].node->count);
  fclose(f);

  return 0;
}

