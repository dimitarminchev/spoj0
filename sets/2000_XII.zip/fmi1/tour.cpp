#include <assert.h>
#include <stdio.h>

#define MAX_N	1000

int n;
long p[MAX_N], s[MAX_N], t[MAX_N];

int main (void) {
  FILE *f;
  int i;
  long minus1, minus2, cur;

  f = fopen("tour.in", "rt");
  assert(f);
  fscanf(f, "%d", &n);
  assert(3 <= n && n <= 1000);
  for (i = 0; i < n; i++)
    fscanf(f, "%ld", &p[i]);
  for (i = 0; i < n-1; i++)
    fscanf(f, "%ld", &s[i]);
  for (i = 1; i < n; i++)
    fscanf(f, "%ld", &t[i]);
  fclose(f);

  minus1 = minus2 = 0;
  for (i = 0; i < n; i++) {
    cur = p[i] + minus1;
    if (minus1 > cur) cur = minus1;
    if (i > 0) {
      long temp = s[i-1] + minus2;
      if (temp > cur) cur = temp;
      temp = t[i] + minus2;
      if (temp > cur) cur = temp;
    }
    minus2 = minus1;
    minus1 = cur;
  }

  f = fopen("tour.out", "wt");
  assert(f);
  fprintf(f, "%ld\n", cur);
  fclose(f);

  return 0;
}