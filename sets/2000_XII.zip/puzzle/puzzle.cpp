//
//  PUZZLE.CPP
//
//  author: Vasil Popovski
//
//

#include <stdio.h>
#include <stdlib.h>

FILE *fout;

//A,B,C,D,E,F, G,H,I,J

int d;
int n;

char puz[20][15];
char dig[10];
char used[10];

long calc(int k) {
  char *s = puz[k];
  long sum=0;
  s++;

  while (*s!=0) {
    sum = sum * d + dig[(*s)-'A'];
    s++;
  }

  return sum;
}

void checkSol() {
  long sum=0;

  /*
  for (int i=0; i<d; i++) printf("%d", dig[i]);
  printf("\n");
  */

  for (int i=0; i<n; i++)
    if (puz[i][0] == '+') {
      sum += calc(i);
    } else {
      sum -= calc(i);
    }

  if (sum==0) {
    for (i=0; i<n; i++) {
      char *s = puz[i];
      if (i>0) fprintf(fout, "%c", *s);
      s++;

      while (*s != 0) {
		fprintf(fout, "%c", '0'+dig[(*s)-'A']);
		s++;
      }
    }

    fprintf(fout, "\n");
    fclose(fout);
    exit(0);
  }
}

void permute(int k) {
  if (k==d) {
    checkSol();
  }

  for (int i=0; i<d; i++)
    if (used[i] == 0) {
      used[i] = 1;
      dig[k] = i;
      permute(k+1);
      used[i] = 0;
    }
}

void solve() {
  for (int i=0; i<10; i++) used[i] = 0;

  permute(0);
}


int main() {
  char c;
  FILE *fin = fopen("PUZZLE.INP", "rt");
  fout = fopen("PUZZLE.OUT", "wt");

  fscanf(fin, "%d\n", &d);

  n = 0;
  puz[0][0] = '+';

  while (fscanf(fin, "%[A-Z]", &(puz[n++][1])) == 1) {
    fscanf(fin, "%c", &c);
    puz[n][0]=c;
    if (c=='=') {
      fscanf(fin, "%[A-Z]", &(puz[n++][1]));
      break;
    }
  }

  solve();

  fprintf(fout, "No solution\n");

  fclose(fin);
  fclose(fout);

  return 0;
}