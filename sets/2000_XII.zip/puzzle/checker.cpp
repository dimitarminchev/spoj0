//
//  PUZZLE.CPP
//
//  author: Vasil Popovski
//
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *fout;

//A,B,C,D,E,F, G,H,I,J

int d;
int n;

char puz[20][15];
char dig[10];

long calc(int k) {
  char *s = puz[k];
  long sum=0;
  s++;

  while (*s!=0) {
	sum = sum * d + dig[(*s)-'A'];
	s++;
  }

  return sum;
}

int checkSol() {
  long sum=0;

  /*
  for (int i=0; i<d; i++) printf("%d", dig[i]);
  printf("\n");
  */

  for (int i=0; i<n; i++)
	if (puz[i][0] == '+') {
	  sum += calc(i);
	} else {
	  sum -= calc(i);
	}

  if (sum==0) {
	return 1;
  }
  return 0;
}


int main() {
  char c, c1;
  char buf[1000];
  FILE *fin = fopen("PUZZLE.INP", "rt");
  FILE *fout = fopen("PUZZLE.OUT", "rt");

  fscanf(fin, "%d\n", &d);

  n = 0;
  puz[0][0] = '+';

  for (int i=0; i<10; i++) dig[i] = '#';

  while (fscanf(fin, "%[A-Z]", &(puz[n++][1])) == 1) {
	fscanf(fin, "%c", &c);

	fscanf(fout, "%[0-9]", buf);
	fscanf(fout, "%c", &c1);


	if (strlen(buf) != strlen(&puz[n-1][1])) {
	  printf("ERROR!!!!.   Len does not match\n");
	  fclose(fin);
	  fclose(fout);
	  exit(0);
	}

	for (i=0; i<strlen(buf); i++) {
	  c1 = puz[n-1][i+1];

	  if (dig[c1-'A'] == '#') dig[c1-'A'] = buf[i]-'0';
	  else
	  if (dig[c1-'A'] != buf[i]-'0') {
		printf("ERROR!!!!.   Multiple values for %c\n", c1);
		fclose(fin);
		fclose(fout);
		exit(0);
	  }
	}

	puz[n][0]=c;
	if (c=='=') {
	  fscanf(fin, "%[A-Z]", &(puz[n++][1]));

	  fscanf(fout, "%[0-9]", buf);
	  fscanf(fout, "%c", &c1);

	  if (strlen(buf) != strlen(&puz[n-1][1])) {
		printf("ERROR!!!!.   Len does not match\n");
		fclose(fin);
		fclose(fout);
		exit(0);
	  }

	  for (i=0; i<strlen(buf); i++) {
		c1 = puz[n-1][i+1];

		if (dig[c1-'A'] == '#') dig[c1-'A'] = buf[i]-'0';
		else
		if (dig[c1-'A'] != buf[i]-'0') {
		  printf("ERROR!!!!.   Multiple values for %c\n", c1);
		  fclose(fin);
		  fclose(fout);
		  exit(0);
		}
	  }

	  break;
	}
  }

  if (checkSol()) {
	printf("OK.\n");
  } else {
	printf("ERROR!!!!.   Sum do not match\n");
  }

  fclose(fin);
  fclose(fout);

  return 0;
}